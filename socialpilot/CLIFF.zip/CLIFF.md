# SocialPilot AI — CLIFF (Continuity Log for AI Future Focus)

## How to use this file

When you (AI agent) receive the instruction **_"Check CLIFF.md"_** or **_"Read CLIFF.md"_** from the user:
1. **First** read this entire file to restore full session context.
2. **Then** read the user's first message to understand what they want next.
3. Proceed as if you had the full conversation history.

---

## Project Overview

**Product:** SocialPilot AI — An "AI Social Sales Agent" for Instagram & Facebook
**Tagline:** "Hire an AI sales employee in 5 minutes."
**Target user:** Small business owners with zero technical knowledge
**Project root:** `socialpilot/`
**Status:** Production scaffold with real Meta OAuth, Docker services running, DB seeded

**Core distinction:** This is NOT a chatbot builder. It's an AI employee that generates leads, converts customers, provides support, and protects reputation autonomously.

---## ⚡ Autonomous Execution Protocol

This protocol governs AI agent behavior to minimize user interaction overhead.

### Core Rule
**Do not ask the user for permission on next steps — ever.** When current tasks are complete, make a logical decision about what to do next and start executing immediately.

**Do not prompt the user with suggested followups.** Analyze all options, prioritize by impact, and begin the next task automatically.

**Continuous Execution Chain:** When one task is completed, immediately evaluate the highest-priority next task from the priority queue or from your own analysis, and begin executing it in the same turn — do not stop and report completion unless there truly is nothing else productive to build or fix. Only pause to ask the user when you hit a true blocker (API key, ambiguous irreversible choice, stuck after 2+ failures, or user explicitly asked for input).

Only ask the user if:
1. You need API keys, secrets, or access credentials that aren't in `.env`
2. The choice is ambiguous with significant irreversible consequences (e.g., "replace the entire Prisma schema")
3. You're stuck after 2+ failed attempts and need guidance
4. The user explicitly asked for input

### Mandatory CLIFF.md Update
**Every workflow MUST end by updating CLIFF.md.** This is not optional. The update must include:
1. A session log entry describing what was accomplished
2. A version bump (minor for incremental work, major for new phases)
3. An updated priority queue reflecting the new state
4. Updated project state summary (phase, TypeScript status, test status)

Updating CLIFF.md is the **final validation step** — it confirms the workflow reached completion. If CLIFF.md hasn't been updated, the workflow is not finished.

### Decision-Making Heuristic
When choosing what to do next, prioritize by:
1. **Unblocking the core workflow** — Wire things that are stubbed/simulated to real data flow
2. **Fixing broken tests/typechecks** — Keep the codebase green
3. **Completing partially built features** — Ship the 80% that exists
4. **Reducing custom code via OSS** — Replace custom modules with mature open-source
5. **UI polish** — Only after core workflow works end-to-end

### Session Flow
- **Session start:** Read CLIFF.md, restore context, immediately start on the highest-priority uncompleted task
- **During session:** Work through tasks sequentially. After each logical workflow completes, **update CLIFF.md** and immediately begin the next highest-priority task
- **Session end:** Bump version, write final summary entry in CLIFF.md
- **If interrupted:** The last CLIFF.md update is the checkpoint — next session reads it and resumes

### Workflow Lifecycle (Mandatory Sequence)
Every workflow (single task or multi-step feature) follows this exact sequence:

```
1. Read CLIFF.md → Determine highest-priority next task
2. Gather context (read files, search codebase, research docs)
3. Write implementation plan (write_todos)
4. Implement changes (edit/create files)
5. Run validation (typecheck + tests in parallel)
6. Fix any issues found
7. Spawn code review (code-reviewer-deepseek-flash)
8. Apply any code review fixes
9. Update CLIFF.md with session log entry + version bump
10. Read updated CLIFF.md → Determine next highest-priority task
11. Go to step 2
```

### No-Manual-Confirmation Zones
The following actions do NOT require user confirmation:
- Running terminal commands (tests, typechecks, builds, Docker)
- Installing npm packages (unless globally)
- Editing any file in the codebase
- Creating/deleting files
- Researching OSS projects and making integration recommendations
- Updating CLIFF.md
- Starting/stopping Docker services
- Running database migrations or seeds

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, TypeScript, Tailwind CSS, ShadCN UI, Lucide Icons |
| Backend | Fastify (Node.js), TypeScript |
| Database | PostgreSQL |
| ORM | Prisma |
| Queue | Redis + BullMQ |
| Auth | JWT + Google OAuth |
| Storage | Supabase Storage |
| Vector DB | Qdrant |
| AI | OpenAI API (future: Ollama, Qwen, Llama) |
| Email | Resend |

---

## Directory Structure

```
socialpilot/
├── packages/
│   └── shared/src/       # Shared types, constants, Zod schemas
├── backend/
│   ├── prisma/            # Prisma schema (18 models)
│   ├── src/
│   │   ├── app.ts         # Fastify app entry + route registration
│   │   ├── config.ts      # Environment config
│   │   ├── plugins/       # prisma.ts, auth.ts (JWT)
│   │   ├── modules/       # 16 route modules
│   │   ├── services/
│   │   │   ├── ai/        # LLM client, classifier, personalities, context builder
│   │   │   ├── webhook/   # Meta webhook processor
│   │   │   ├── memory/    # Customer memory service
│   │   │   ├── vector/    # Qdrant vector store (RAG)
│   │   │   └── queue/     # BullMQ queue service
│   │   └── utils/
│   └── tests/
├── frontend/
│   ├── src/
│   │   ├── app/           # Auth + Dashboard pages
│   │   ├── components/    # ui/, layout/, shared/
│   │   ├── lib/           # api.ts, utils.ts
│   │   └── hooks/
│   └── public/
├── workers/src/           # BullMQ workers (comment, dm, re-engagement)
├── docker-compose.yml     # PostgreSQL + Redis + Qdrant + backend + workers
├── ARCHITECTURE_REVIEW.md # Full OSS evaluation + phased implementation plan
├── .env.example
└── package.json           # Monorepo workspace root
```

---

## What Has Been Built (Complete)

### Backend API — 16 route modules, all registered in app.ts

| Module | Prefix | Key Endpoints |
|--------|--------|--------------|
| Auth | `/api/auth` | POST `/register`, POST `/login`, GET `/me`, POST `/google` |
| Meta | `/api/meta` | GET `/webhook`, POST `/webhook`, GET `/auth`, GET `/callback` |
| Comments | `/api/comments` | CRUD + classification |
| DMs | `/api/dms` | CRUD conversations + messages |
| Leads | `/api/leads` | CRUD with pagination, search, category filter |
| CRM | `/api/crm` | Kanban deals, activities, stage transitions |
| Inbox | `/api/inbox` | Unified inbox with priority, status, type filters |
| Analytics | `/api/analytics` | GET `/overview`, `/leads`, `/growth`, `/insights`, POST `/insights/generate` |
| Knowledge | `/api/knowledge` | CRUD documents |
| Escalation | `/api/escalations` | CRUD tickets, resolve |
| Re-engagement | `/api/reengagement` | CRUD rules |
| Onboarding | `/api/onboarding` | GET `/`, PUT `/step`, POST `/complete` |
| CTA | `/api/cta` | CRUD CTA configs |
| Team | `/api/team` | CRUD team members, invite |
| Notifications | `/api/notifications` | List, mark read |
| Admin | `/api/admin` | Usage stats, audit log |

### Services
- **LLM:** OpenAI client with `generateCompletion()` and `generateJSON()`
- **Classifier:** Comment + DM intent classification with detailed scores
- **Personalities:** 5 preset personalities with tone prompts and temperatures
- **Context Builder:** Assembles FAQ knowledge, customer memory, brand settings
- **Memory Service:** Per-customer persistent memory with journey tracking
- **Vector Service:** Qdrant client for RAG embedding search
- **Queue Service:** BullMQ queues for comment/DM/re-engagement processing
- **Webhook Processor:** Parses Meta webhook events into comments + DM conversations

### Background Workers (BullMQ)
- **Comment Worker:** Classify → Generate response → Create leads → Publish
- **DM Worker:** Load customer memory → Generate contextual response → Create leads
- **Re-engagement Worker:** 24h/3d/7d follow-up stages

### Frontend Pages
Auth (login/register), Dashboard, Inbox, Leads, CRM Kanban, Growth, Insights, Knowledge, Team, Settings, 7-step Onboarding wizard

### Prisma Schema — 18 models
User, TeamMember, MetaConnection, MetaWebhook, SocialComment, DMConversation, DMMessage, Lead, CRMDeal, CRMActivity, KnowledgeDocument, CTAConfig, BrandSettings, EscalationTicket, CustomerMemory, Insight, Notification, ApprovalRequest, MissedOpportunity, AuditLogEntry, Subscription, UsageRecord, InboxItem, ReEngagementRule

### Shared Types Package
Comprehensive types for all modules

---

## OSS Integration Strategy (from ARCHITECTURE_REVIEW.md)

| OSS Project | Decision | When |
|-------------|----------|------|
| **Meta Webhook Processing** | Implement now (unlocks entire product) | **Phase 1 — IN PROGRESS** |
| **Mem0** | Replace custom MemoryService | Phase 1 |
| **Mastra** | Orchestrate AI pipeline | Phase 1 |
| **Chatwoot** (headless) | Replace Inbox/Comments/DMs modules | Phase 2 |
| **Metabase** | Embedded analytics (paid plan) | Phase 3 |
| **n8n** | Replace re-engagement scheduling | Phase 3 |
| **Meta Business SDK** | Partial (OAuth only, not social APIs) | Low priority |
| **Twenty CRM** | Schema patterns only, no integration | Inspirational |
| **Open WebUI** | RAG patterns only, no platform | Low priority |

---

## What Has NOT Been Built

WhatsApp, Telegram, LinkedIn, TikTok integrations, Agency/White Label mode, Visual Workflow Builder — all deferred from MVP.

---

## Known Gaps / Priority Queue

### ✅ COMPLETED — Phase 1
1. ✅ Real Meta OAuth (v1.2)
2. ✅ Webhook Processor — Routes payloads to comment/DM workers (v1.4)
3. ✅ End-to-end AI reply pipeline — Workers classify, generate, create leads, create CRM deals (v1.4)
4. ✅ Mem0 semantic memory integration (v1.5)
5. ✅ Mastra pipeline orchestration — Workers delegate to typed Mastra workflows (v1.6)
6. ✅ Lead auto-creation from qualified conversations
7. ✅ CRM deal auto-creation from qualified leads

### HIGH — Next priority
8. ❌ **Dashboard shows real data** — Frontend pages are shells with mock data placeholder text
9. ❌ **Analytics with real data** — Backend routes exist, frontend shows hardcoded data

### MEDIUM — Post-MVP polish
10. ❌ Chatwoot unified inbox
11. ❌ n8n re-engagement automation

---

## Architectural Decisions

- **Monorepo** using npm workspaces
- **Frontend API calls** use `NEXT_PUBLIC_API_URL` (default `http://localhost:4000`)
- **JWT auth** uses `@fastify/jwt` plugin with Bearer token pattern
- **Prisma naming quirk:** All-caps model names like `CTAConfig` become `cTAConfig`
- **Fastify plugin pattern:** All plugins use `fastify-plugin` with `fp()` wrapper
- **Webhook processing:** Meta webhooks → WebhookProcessor service → BullMQ workers → AI pipeline

---

## Key File Paths Reference

| Purpose | Path |
|---------|------|
| Root monorepo config | `socialpilot/package.json` |
| Shared types | `socialpilot/packages/shared/src/types/index.ts` |
| Backend entry | `socialpilot/backend/src/app.ts` |
| Backend config | `socialpilot/backend/src/config.ts` |
| Prisma schema | `socialpilot/backend/prisma/schema.prisma` |
| Meta routes | `socialpilot/backend/src/modules/meta/routes.ts` |
| Webhook processor | `socialpilot/backend/src/services/webhook/meta-processor.ts` |
| Comment worker | `socialpilot/workers/src/comment.worker.ts` |
| DM worker | `socialpilot/workers/src/dm.worker.ts` |
| AI LLM service | `socialpilot/backend/src/services/ai/llm.ts` |
| AI classifier | `socialpilot/backend/src/services/ai/classifier.ts` |
| Memory service | `socialpilot/backend/src/services/memory/memory-service.ts` |
| Queue service | `socialpilot/backend/src/services/queue/queue-service.ts` |
| Architecture review | `socialpilot/ARCHITECTURE_REVIEW.md` |
| Frontend entry | `socialpilot/frontend/src/app/layout.tsx` |
| API client | `socialpilot/frontend/src/lib/api.ts` |
| Docker Compose | `socialpilot/docker-compose.yml` |
| Env template | `socialpilot/.env.example` |

---

## Session Log

### v1.0 — Session 1 (Initial Build)
7-step onboarding, AI Insights Engine, Google OAuth, Next.js proxy, Prisma model fixes

### v1.1 — Session 1.5 (CLIFF Setup)
Created CLIFF.md with auto-update protocol, documented full project state

### v1.2 — Session 2 (Setup & Infrastructure)
Dependencies installed, DB seeded, Real Meta OAuth integration, Docker Compose

### v1.3 — Session 3 (TypeScript Cleanup)
Fixed 9+ TS errors across backend/frontend/workers, module docs, deployment guide

### v1.4 — Session 4 (Autonomous Protocol + Phase 1 Webhook Pipeline) ✅
**Meta changes:**
1. ✅ **Autonomous Execution Protocol** — Hard-coded directive: AI never asks for permission on next steps. Makes logical decisions and executes immediately.
2. ✅ **ARCHITECTURE_REVIEW.md** — Comprehensive 30-page OSS evaluation covering 8 projects with phased implementation plan
3. ✅ **Webhook Processor Service** — Created `backend/src/services/webhook/meta-processor.ts` that parses real Meta webhook entries into typed events (comments, messages, mentions) and routes them to the correct processing pipelines
4. ✅ **Meta routes updated** — `POST /webhook` now uses the processor to classify events, create DB records, and queue jobs
5. ✅ **Comment worker updated** — Now auto-creates Leads (score > 50) and CRM Deals (score > 70) after classification
6. ✅ **DM worker updated** — Now updates CustomerMemory and auto-creates Leads (score > 50) after classification
7. ✅ **CLIFF.md v1.4** — Updated with autonomous protocol, session log, and current priority queue

### v1.5 — Session 5 (Phase 1 — Mem0 Semantic Memory Integration) ✅

### v1.6 — Session 6 (Phase 1 — Mastra Pipeline Orchestration) ✅
**Mastra integration:**
1. ✅ **comment-pipeline.ts** — 4-step typed Mastra workflow: classify → create lead → generate AI reply → update comment
2. ✅ **dm-pipeline.ts** — 5-step typed Mastra workflow: classify → update customer memory → create lead → generate AI reply → store reply + Mem0
3. ✅ **mastra/index.ts** — Entry point with runCommentPipeline()/runDMPipeline() helpers, uses createRun() → start({ inputData }), handles success/failed/tripwire statuses
4. ✅ **Workers simplified** — comment.worker.ts and dm.worker.ts delegate to Mastra instead of inline pipeline logic

### v1.7 — Session 7 (Dashboard Real Data) ✅
**Frontend wired to real APIs:**
1. ✅ **Team page** — Replaced hardcoded mock data with real API calls to /api/team. Loading/empty/error states. Invite/remove wired to backend.
2. ✅ **Settings module** — Created backend/src/modules/settings/routes.ts (GET/ + PUT / for BrandSettings CRUD with auto-create). Registered at /api/settings.
3. ✅ **Settings page** — Wired to /api/settings for load + save. Uses real backend persistence for business name, personality, automation toggles.
4. ✅ **Settings test** — Updated mocks to use mockResolvedValueOnce pattern matching the new dual-API call.
5. ✅ **TypeScript** — Zero errors across all 4 projects.
6. ✅ **Tests** — Backend 135/135, frontend 55/55.

### v1.8 — Session 8 (Knowledge Base Upload) ✅
**File upload implemented:**
1. ✅ **@fastify/multipart** — Installed and registered in app.ts with 10MB limit
2. ✅ **POST /api/knowledge/upload** — Replaced 501 stub with real file handler
   - Supports .txt, .md, .csv, .json, .xml, .html
   - Unsupported types get link-only document with format note
   - Auto-detects doc type from content keywords (pricing/product/policy)
   - Extracts title from first line or filename
   - Try/catch around multipart parsing for malformed uploads
3. ✅ **TypeScript** — Zero errors

### v1.9 — Session 9 (Chatwoot Headless Inbox Integration) ✅
**Chatwoot module created:**
1. ✅ **chatwoot-service.ts** — HTTP client wrapping Chatwoot REST API v1 with lazy init from env vars
2. ✅ **chatwoot/routes.ts** — 4 endpoints (status, webhook, sync/contact, sync/message)
3. ✅ **chatwoot/README.md** — Config guide
4. ✅ **app.ts registration** — chatwootRoutes at /api/chatwoot
5. ✅ **Auth guard fix** — Webhook skips JWT unless Authorization header present
6. ✅ **TypeScript** — Zero errors

### v1.10 — Session 10 (n8n Re-engagement Automation Bridge) ✅
**n8n integration module:**
1. ✅ **n8n-service.ts** — Webhook trigger service with lazy init from env vars. AbortController timeout. Graceful { triggered: false } when not configured.
2. ✅ **n8n/routes.ts** — 4 endpoints: GET /status, PUT /config, POST /test, POST /trigger/reengagement
3. ✅ **n8n/README.md** — Webhook setup with expected payload schema
4. ✅ **reengagement.worker.ts** — Checks n8n first, falls back to inline LLM generation
5. ✅ **Shared types** — ReEngagementJobData has customerName? and leadScore?
6. ✅ **app.ts registration** — n8nRoutes at /api/n8n
7. ✅ **TypeScript** — Zero errors across all 4 projects

### v1.11 — Session 11 (E2E Pipeline Integration Tests) ✅
**Full pipeline tests added:**
1. ✅ **e2e-pipeline.test.ts** — 16 tests across 4 suites covering the complete data flow:
   - Meta Webhook → Comment: Verifies webhook ingestion stores raw webhook, creates SocialComment with correct fields (authorName, content, platform, replyStatus), data shaped for Mastra comment pipeline
   - Meta Webhook → DM: Verifies DMConversation + DMMessage creation with proper senderId/role/content
   - Lead & CRM Creation: Tests pipeline output DB operations — lead creation (score 72, warm), CRMDeal linked to lead, CRMActivity for deal tracking
   - Knowledge & Context Builder: Creates knowledge document for RAG context, CustomerMemory with journey tracking
2. ✅ BullMQ mocked — vi.mock(queue-service) prevents Redis connection failures in test env
3. ✅ All 16/16 passing, TypeScript zero errors

---

## Project State

**Current phase:** Phase 3 — Revenue Attribution & Business Value Features
**Docker:** PostgreSQL, Redis, Qdrant running
**Database:** Seeded with demo user (demo@socialpilot.ai / demo1234)
**TypeScript:** Backend + Frontend both pass ✅
**Tests:** Backend (existing) ✅, Frontend (existing) ✅

**Phase 1 — Core Pipeline:**
1. ✅ Real Meta OAuth
2. ✅ Webhook Processor
3. ✅ End-to-end AI reply pipeline
4. ✅ Mem0 semantic memory
5. ✅ Mastra pipeline orchestration
6. ✅ Lead + CRM auto-creation
7. ✅ Dashboard real data (Team + Settings wired)
8. ✅ Analytics + Insights engine
9. ✅ Knowledge base file upload

**Phase 2 — OSS Integration Bridges + Testing:**
10. ✅ Chatwoot headless inbox
11. ✅ n8n re-engagement automation
12. ✅ E2E pipeline integration tests

**Phase 3 — Revenue Attribution & Business Value (v2.0) — COMPLETED:**
13. ✅ **Revenue Analytics** — `/api/revenue/summary`, `/trend`, `/funnel`, `/executive-summary` endpoints with period filtering, AI attribution %, conversion metrics
14. ✅ **Missed Opportunity Detection** — `/api/missed-opportunities/detect` scans for pricing questions unanswered, purchase intent missed, stalled DMs, stale hot leads. Create leads from missed opportunities with Recover Lead button
15. ✅ **Human Approval Mode** — BrandonSettings includes approvalModeType (fully_automatic, approval_required, hybrid). `/api/approvals` — list, approve, reject, edit & publish with confidence scores. Approval/Rejection rate tracking
16. ✅ **Reputation Dashboard** — `/api/reputation/overview` with reputation score (0-100), sentiment breakdown (positive/neutral/negative %), crisis alerts, sentiment trend data
17. ✅ **Customer Journey Timeline** — `/api/timeline/lead/:leadId` + `/api/timeline/customer/:handle` — full event history (comments, DMs, AI replies, CRM changes, deal won)
18. ✅ **CRM Pipeline Enhanced** — Revenue field, deal status (open/qualified/proposal/won/lost), pipeline value, win rate, AI revenue % with inline timeline modal
19. ✅ **Insights Revenue Summaries** — Executive summary cards with leads generated, opportunities, deals won, revenue, AI attribution percentage bar
20. ✅ **Growth Page** — Revenue trend charts, conversion funnel visualization
21. ✅ **Dashboard Transformation** — Real data widgets: executive summary, revenue metrics, missed opportunities stats, reputation score
22. ✅ **New Frontend Pages** — Approvals Queue, Missed Opportunities, Reputation Dashboard — all wired to real backend APIs
23. ✅ **New Backend Modules** — 5 new modules with READMEs: missed-opportunities, approvals, revenue, reputation, timeline
24. ✅ **Sidebar Navigation** — Updated with Approvals, Missed Opps, Reputation links

### v2.2 — Session 12 (PostHog Product Analytics Integration) ✅
**PostHog event tracking implemented:**
1. ✅ **Backend PostHog service** — `backend/src/services/analytics/posthog.ts` with `captureEvent()`, `identifyUser()`, shutdown. Events constant covers all user actions.
2. ✅ **Frontend PostHog client** — `frontend/src/lib/posthog-client.ts` + `frontend/src/app/PostHogInit.tsx` client component in layout
3. ✅ **Config** — `config.ts` with `posthog.apiKey`, `posthog.host`, graceful degradation when env vars unset
4. ✅ **Route tracking** — Events fired in: auth (signup/login), onboarding (step/complete), meta (connect/disconnect), CTA (create/update), leads (create/update/convert), CRM (stage changes), knowledge (upload)
5. ✅ **Admin health** — PostHog status (enabled/disabled) in `/api/admin/health`
6. ✅ **Funnels page** — `/funnels` in sidebar showing signup-to-deals conversion with 5 funnel stages and drop-off rates
7. ✅ **TypeScript** — Zero errors across all projects

### v2.3 — Session 13 (Sentry Error Monitoring Integration) ✅
**Sentry error tracking implemented:**
1. ✅ **Backend Sentry service** — `backend/src/services/sentry/sentry.ts` with cached `require()`, graceful degradation, `captureException()`, `captureMessage()`, `setUser()`, `flushSentry()`
2. ✅ **Fastify error handler** — `setupFastifyErrorHandler()` registered in app.ts to catch all unhandled route errors
3. ✅ **Worker Sentry integration** — All 3 workers (comment, dm, reengagement) wrap job processors with try/catch and Sentry capture
4. ✅ **Frontend Sentry init** — `frontend/src/lib/sentry.ts` + `frontend/src/app/SentryInit.tsx` client component with `Sentry.init()` in useEffect
5. ✅ **Admin health** — Sentry status (DSN configured, initialized) in `/api/admin/health`
6. ✅ **Admin Health Dashboard** — Shows Sentry status, queue health (pending/active/delayed counts), error count
7. ✅ **Graceful shutdown** — `flushSentry()` called before process exit in SIGTERM/SIGINT handlers
8. ✅ **TypeScript** — Zero errors across all projects

### v2.4 — Session 14 (Phase 3 Module Tests) ✅
**57 integration tests added for Phase 3 modules:**
1. ✅ **revenue.test.ts** — 8 tests: summary with periods, won deal calculation, AI attribution %, trend data, funnel, executive summary
2. ✅ **missed-opportunities.test.ts** — 12 tests: pricing/purchase intent detection, duplicate avoidance, list/filter/stats, resolve/dismiss, recover lead from opportunity
3. ✅ **approvals.test.ts** — 12 tests: list/paginate/filter by status, approve/reject flows, edit-publish, approval stats
4. ✅ **reputation.test.ts** — 8 tests: overview with score (0-100) & sentiment breakdown, active alerts, sentiment trend (sorted by date), alerts filtered/ordered
5. ✅ **timeline.test.ts** — 17 tests: lead timeline (all event types: comment, ai_reply, dm, deal, journey), sorted by timestamp, 404, customer timeline by handle, empty timeline
6. ✅ **setup.ts** — Cleanup for new models (ApprovalRequest, MissedOpportunity)
7. ✅ **Database sync** — `prisma db push` applied (new columns: customerName, confidenceScore, reputationAlert, revenue)
8. ✅ **TypeScript** — Zero errors across all projects

### v2.5 — Session 15 (UI Polish & Consistency Pass) ✅
**All Phase 3 pages polished with consistent UX patterns:**
1. ✅ **Approvals Queue** — Sonner toasts, skeleton cards, confidence badges, edit-publish flow
2. ✅ **Missed Opportunities** — Sonner toasts, skeleton cards, staggered animations
3. ✅ **Reputation Dashboard** — SVG score gauge, SentimentCard sub-components
4. ✅ **Conversion Funnels** — SkeletonFunnel + error state with retry
5. ✅ **Analytics overview endpoint** — Aggregate fields for funnel page
6. ✅ **TypeScript** — Zero errors

### v2.6 — Session 16 (Inbox Page Polish) ✅
**Unified inbox fully enhanced with real-time UX patterns:**
1. ✅ **Skeleton loading rows** (8) with pulse animation
2. ✅ **Combined filters** — Status + Priority + Search
3. ✅ **Checkbox selection** — Select all + individual with bulk Mark Read / Resolve
4. ✅ **Detail panel** — Message bubble, AI Suggested Reply, quick-reply textarea with Send
5. ✅ **Quick actions** — Mark Replied, Resolve, Assign, Escalate
6. ✅ **Auto-refresh** — 30s polling + manual Refresh button
7. ✅ **Pagination** — Previous/Next with page x of y indicator
8. ✅ **Empty state** — Filter-clear button when filters active
9. ✅ **Unread/urgent badges** — Header badges from current page data
10. ✅ **TypeScript** — Zero errors, all 208 backend tests pass

### v2.7 — Session 17 (Chatwoot Unified Inbox Integration) ✅
**Chatwoot conversations merged into the unified inbox:**
1. ✅ Platform filter in inbox routes + ChatwootService methods (listConversations, getConversation)
2. ✅ Chatwoot conversations endpoint + sync endpoint with duplicate detection
3. ✅ Frontend: Platform filter dropdown, badge colors per platform, Bot icon for Chatwoot
4. ✅ Frontend: Config banner + sync button (only when configured)
5. ✅ TypeScript — Zero errors, all 208 tests pass

### v2.8 — Session 18 (n8n Re-engagement Automation Page) ✅
**Full re-engagement management page created with n8n integration:**
1. ✅ **Frontend: Re-engagement page** — New page at `/reengagement` with full n8n workflow management
2. ✅ **n8n status bar** — Green/amber banner showing n8n connection status, base URL, API key presence
3. ✅ **Rules editor** — Enable/disable toggle, collapsible stage template cards (24h/3d/7d) with delay dropdown and message template textarea, add/remove stages
4. ✅ **Conditions section** — Toggles for "Only dormant leads" and "Exclude customers", minimum lead score input
5. ✅ **Save button** — Wired to `PUT /api/reengagement/rules` with loading spinner
6. ✅ **Test webhook** — Webhook ID input + Test button with success/error result display (JSON preview for success)
7. ✅ **Dormant leads list** — Fetched from `GET /api/reengagement/candidates`, shows name/category/score/platform/last contact, per-lead Re-engage button (POST /api/n8n/trigger/reengagement) with hover visibility
8. ✅ **Sidebar** — Added "Re-engage" link with Zap icon
9. ✅ **Loading/empty/error states** — Skeleton blocks, empty states with helpful text, disabled buttons when n8n not configured
10. ✅ **TypeScript** — Zero errors, all 208 tests pass

### v2.10 — Session 20 (All Remaining Priorities — Health Monitoring, E2E Tests, Deploy, Demo Assets, Reporting) ✅
**All 5 remaining Phase 4 priorities completed in one session:**

**Priority 6 — Meta Health Monitoring:**
1. ✅ **GET /api/meta-health/overview** — Composite health score (0-100), alerts (critical/warning/info), connection health with token expiry badges, webhook delivery stats (total/24h/7d/success rate), error summary with last 10 errors
2. ✅ **POST /api/meta-health/check** — Proactive health check pinging Meta Graph API for each connection. Auto-marks connections as 'error' on 401/403. Returns per-connection reachable/error status
3. ✅ **GET /api/meta-health/history** — Connection history with webhook counts
4. ✅ **Frontend /health page** — SVG score gauge, alert banners with severity colors, connection cards with TokenBadge (expired/expiring soon/healthy), stat cards, Run Health Check button with inline results, error log
5. ✅ **Sidebar** — Added "Health" link with Activity icon

**Priority 7 — Playwright End-to-End Tests:**
6. ✅ **Playwright installed** — via pnpm, chromium browser
7. ✅ **playwright.config.ts** — Config with webServer for backend + frontend, html reporter, chromium only
8. ✅ **e2e/user-journey.spec.ts** — 5 tests: full page navigation (15 pages), sidebar link verification, health page rendering, settings page sections, API health endpoint

**Priority 8 — VPS Deployment Package:**
9. ✅ **deploy/docker-compose.prod.yml** — Production Compose with nginx (reverse proxy + SSL), certbot (Let's Encrypt auto-renewal), frontend (Dockerfile.frontend), backend, postgres (with password), redis (with password), qdrant, comment-worker, dm-worker. Healthchecks, restart policies, isolated network
10. ✅ **deploy/nginx.conf** — HTTP→HTTPS redirect, SSL termination (TLSv1.2/1.3), rate limiting (30r/s API, 100r/s webhook), security headers (HSTS, XSS, X-Frame), static asset caching, separate frontend/API subdomains
11. ✅ **deploy/.env.prod.example** — All 25+ secrets documented with placeholders
12. ✅ **deploy/setup-ssl.sh** — Certbot SSL provision with auto-renew cron job
13. ✅ **deploy/deploy.sh** — Full lifecycle: DB backup → pull → build → start → migrate → seed (first deploy only) → healthcheck → cleanup
14. ✅ **Dockerfile.frontend** — Multi-stage build with pnpm, Next.js standalone output, non-root user

**Priority 9 — Sales Demo Assets:**
15. ✅ **demo/demo-video-script.md** — 3-minute script: hook → problem → solution (1-click connect) → AI in action (auto-reply, lead capture, CRM) → dashboard → results (10x leads, 100% response) → CTA
16. ✅ **demo/one-pager.md** — Features table (auto-reply, lead capture, smart CRM, knowledge base, approval mode, analytics), pricing ($0/$29/$79/Agency), before/after results (5→50+ leads, 40%→100% response), testimonials, key differentiators
17. ✅ **demo/presentation-outline.md** — 10-slide deck: title, hidden sales channel, cost of inaction, solution, product demo, features, ROI, case study (Elite Dental Clinic), pricing, CTA. Appendix: technical requirements, security, competitive comparison

**Priority 10 — Customer Reporting Engine:**
18. ✅ **GET/PUT /api/reports/config** — Report configuration persisted as JSON in BrandSettings.customInstructions under `reportConfig` key. Fields: enabled, frequency (weekly/monthly), email, toggleable sections (leads/revenue/conversations/reputation/recommendations), dayOfMonth
19. ✅ **POST /api/reports/generate** — Gathers real metrics (leads captured/converted/conversion rate, conversations/comments/DMs, revenue/deals won, reputation score), generates styled HTML email template with summary, 4-card grid, AI attribution section, recommendations
20. ✅ **Frontend /reports page** — Config form with toggles/scheduling, quick stats cards, Generate Report button, generated report preview with summary + 4-metric display + HTML iframe preview
21. ✅ **Sidebar** — Added "Reports" link with BarChart3 icon

## Priority Queue (Updated)

### ✅ COMPLETED — Phase 1
1–6. Core pipeline (Meta OAuth, Webhook, AI pipeline, Mem0, Mastra, Lead/CRM auto-creation)

### ✅ COMPLETED — Phase 2
7–12. OSS Integration bridges (Dashboard data, Analytics, Knowledge upload, Chatwoot, n8n, E2E tests)

### ✅ COMPLETED — Phase 3
13–24. Revenue attribution & business value (Revenue analytics, Missed opps, Approvals, Reputation, Timeline, CRM enhanced, Insights, Growth, Dashboard, 5 new modules, Sidebar)

### ✅ COMPLETED — Phase 4 (Commercialization)
25. PostHog product analytics
26. Sentry error monitoring
27. Phase 3 module tests (57 integration tests)
28. UI polish pass
29. Inbox page polish
30. Chatwoot unified inbox
31. n8n re-engagement automation page
32. Customer Success Dashboard (Priority 5)
33. White-Label Config + Brand Editor
34. API Keys & Webhooks management
35. Team Collaboration + Activity Feed
36. **Meta Health Monitoring** — Webhook delivery health, token expiry alerts, connection status dashboard
37. **Playwright End-to-End Tests** — Full user journey tests (15 pages, sidebar, health, settings, API)
38. **VPS Deployment Package** — Docker Compose production config, nginx + SSL, deploy script
39. **Sales Demo Assets** — Demo video script, one-pager, customer presentation outline
40. **Customer Reporting Engine** — Email/Slack monthly reports with real metrics and HTML template

### ✅ PHASE A — Razorpay Billing
Complete billing UI with plan cards (Starter ₹2,900 / Professional ₹7,900 / Agency ₹19,900), Razorpay Checkout integration (dynamic script load, order creation, payment verification, signature validation), GST input, billing history with invoice download, cancel/downgrade flows, usage & quotas dashboard with 80%/90%/exceeded warnings.

### ✅ PHASE B — Usage Enforcement
Hard usage limits across 6 metrics (AI responses, leads, Meta connections, team members, CRM deals, knowledge docs). 80% → amber warning, 90% → orange warning, 100% → hard stop. UsageBadge in sidebar, UsageLimitBanner on pages, usage enforcer checks before every mutation. Per-period tracking with auto-reset.

### ✅ PHASE C — Demo Mode
Complete demo environment: DemoBanner with amber gradient, company name display, regenerate button. Demo shows "Elite Dental Clinic" with realistic leads, CRM deals, conversations, revenue. Demo data auto-resets. Salesperson can demo without connecting Meta.

### ✅ PHASE D — Onboarding Success Engine
OnboardingHealthScore widget in sidebar: 7-point checklist (Meta connected, webhooks, FAQ uploaded, CTA added, personality selected, approval mode, knowledge base), score gauge (0-100), progress bar, next best action card with description and link, skeleton loading, perfect-score celebration.

### ✅ PHASE E — Customer Reporting System
Configurable reports (enabled, frequency, email, toggles for sections), styled HTML email template with summary, 4-metric grid (leads captured/converted/conversion rate, conversations, revenue, reputation), AI attribution, recommendations. Frontend page with config form + generate + preview.

### ✅ PHASE F — Meta Health Center
Health monitoring: composite score (0-100), alerts (critical/warning/info), connection health with token expiry badges (expired/expiring soon/healthy), webhook delivery stats (total/24h/7d/success rate), error summary. Proactive health check pinging Meta Graph API. Frontend score gauge, alert banners, connection cards, Run Health Check button.

### ✅ PHASE G — Partner Distribution System
Partner CRUD (name, email, phone, city, territory, commission %), associate customer to partner via referredByPartner, self-service partner portal (clients, MRR, commission earned, client table), commission history (monthly records), admin partner management with stats dashboard. Prisma models: Partner, CommissionRecord.

### ✅ PHASE H — Deployment Readiness
DEPLOY_PRODUCTION.md with 9 sections: architecture, prerequisites, quick deploy, VPS setup, Docker, SSL (Let's Encrypt + certbot auto-renew), backups, restore, monitoring (Docker logs, healthcheck, uptime monitoring, log rotation, alerting). deploy/docker-compose.prod.yml, nginx.conf, setup-ssl.sh, deploy.sh. Dockerfile.frontend (multi-stage, pnpm, standalone).

### ✅ PHASE I — Sales Assets
DEMO_SCRIPT.md with 5-min demo, 15-min sales demo, 4 industry ROI calculations (dental, restaurant, real estate, gym), 10 common objections with professional responses, 6 industry-specific selling guides (hotels, clinics, salons, restaurants, gyms, real estate). Plus demo-video-script.md (3-min), one-pager.md, presentation-outline.md (10 slides + appendix).

## ALL SUCCESS CRITERIA MET ✅

| # | Criterion | Status |
|---|-----------|--------|
| 1 | Customer can sign up | ✅ Auth routes + UI |
| 2 | Customer can pay via Razorpay | ✅ Billing page + subscription module |
| 3 | Customer can connect Meta | ✅ OAuth + callback |
| 4 | Customer can upload FAQ | ✅ Knowledge upload |
| 5 | Customer can add CTA | ✅ CTA config |
| 6 | AI can reply automatically | ✅ Workers + Mastra pipelines |
| 7 | Leads are generated | ✅ Auto-creation from conversations |
| 8 | CRM tracks opportunities | ✅ Kanban + stage transitions |
| 9 | Revenue is tracked | ✅ Revenue analytics + attribution |
| 10 | Usage limits are enforced | ✅ 80%/90%/exceeded with hard stops |
| 11 | Reports are automated | ✅ Configurable email reports |
| 12 | Demo mode works | ✅ DemoBanner + regenerable data |
| 13 | Partner tracking works | ✅ Backend + portal frontend |
| 14 | Deployment documentation exists | ✅ DEPLOY_PRODUCTION.md + deploy/ |

## CLIFF Version

Current version: **v2.15** — **LAUNCH READY** 🚀
